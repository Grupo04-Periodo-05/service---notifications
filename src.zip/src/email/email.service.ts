import * as nodemailer from 'nodemailer';
import * as fs from 'fs';
import * as path from 'path';

type EmailType = 'tarefa-vencendo' | 'esqueceu-senha';

interface EmailParams {
  to: string;
  nomeUsuario: string;
  tituloTarefa?: string;
  disciplina?: string;
  dataVencimento?: string;
  codigo?: string;
}

function loadTemplate(type: EmailType): string {
  const filePath = path.join(__dirname, 'templates', `${type}.html`);
  return fs.readFileSync(filePath, 'utf-8');
}

function renderTemplate(template: string, variables: Record<string, string>) {
  return template.replace(/{{(.*?)}}/g, (_, key) => variables[key.trim()] || '');
}

const transporter = nodemailer.createTransport({
  host: 'in-v3.mailjet.com',
  port: 587,
  secure: false,
  auth: {
    user: process.env.MJ_API_KEY || 'SUA_API_KEY',
    pass: process.env.MJ_API_SECRET || 'SEU_API_SECRET'
  }
});

export async function sendEmail(type: EmailType, params: EmailParams) {
  const dataAtual = new Date().toLocaleDateString('pt-BR');
  const subjectMap = {
    'tarefa-vencendo': `📌 Tarefa prestes a vencer: ${params.tituloTarefa}`,
    'esqueceu-senha': '🔐 Recuperação de senha'
  };

  const htmlTemplate = loadTemplate(type);
  const html = renderTemplate(htmlTemplate, {
    nomeUsuario: params.nomeUsuario,
    tituloTarefa: params.tituloTarefa ?? '',
    disciplina: params.disciplina ?? '',
    dataVencimento: params.dataVencimento ?? '',
    codigo: params.codigo ?? '',
    dataAtual
  });

  const mailOptions = {
    from: '"Notificações" <no-reply@seudominio.com>',
    to: params.to,
    subject: subjectMap[type],
    html
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`📤 E-mail "${type}" enviado com sucesso: ${info.messageId}`);
  } catch (error) {
    console.error('❌ Erro ao enviar e-mail:', error);
  }
}
