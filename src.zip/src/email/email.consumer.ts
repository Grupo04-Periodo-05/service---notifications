import { EmailService } from './email.service';

export const handleEmailMessage = async (msg: any) => {
  const content = JSON.parse(msg.content.toString());
  const emailService = new EmailService();
  await emailService.sendEmail(
    content.to,
    content.subject,
    content.text,
    content.html
  );
};
