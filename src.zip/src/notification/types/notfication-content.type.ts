export interface NotificationContent {
    taskId: string;
    taskTitle: string;
  }